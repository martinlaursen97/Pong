package players;

import gameobjects.Paddle;

public class Human extends Player {
    public Human(Paddle paddle) {
        super(paddle);
    }
}
