package maps;

public class Court {
    public static void createMap() {

    }
}
