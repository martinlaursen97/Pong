package constants;

public enum Difficulty {
    EASY, MEDIUM, HARD, IMPOSSIBLE
}
