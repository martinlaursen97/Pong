package constants;

public enum Part {
    TOP, TOPMID, MID, BOTTOMMID, BOTTOM
}
