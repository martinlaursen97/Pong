package gameobjects;

public class Wall extends GameObject {
    public Wall(int posX, int posY) {
        super(posX, posY);
    }
}
